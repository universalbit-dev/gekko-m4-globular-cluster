# Supporting the project

Gekko is free and open source software. We don't make any money by publishing it, keeping it up to date or providing support.

If Gekko helped you in any way (financially or otherwise) feel free to donate. If you want to see a specific feature implemented faster, feel free to [send an e-mail](mailto:gekko@mvr.me) to discuss.

- Bitcoin tip jar: 13r1jyivitShUiv9FJvjLH7Nh1ZZptumwW
- Ethereum tip jar: 0x46e9249ADc30F5bfc6632e1d0b4286496d071Be7