# Roadmap

Gekko is ever evolving and we are constantly working on new features and upgrades!

This is a small selection of things currently on the roadmap:

## Current TODO

- Improve stability of new event and backtest engine
- Port the old supported exchanges to Gekko Broker
- new UI, see [here](https://forum.gekko.wizb.it/thread-1429-post-58996.html)
- advanced orders from your strategy (Take Profit and Stop Loss)